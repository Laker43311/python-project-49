#!/usr/bin/env python3
from brain_games import calc


def main():
    calc.brain_calc()


if __name__ == '__main__':
    main()
