#!/usr/bin/env python3

from brain_games import even


def main():
    even.brain_even()


if __name__ == '__main__':
    main()
