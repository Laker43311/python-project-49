### Hexlet tests and linter status:
[![Actions Status](https://github.com/Laker43311/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Laker43311/python-project-49/actions)
<a href="https://codeclimate.com/github/Laker43311/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/5cc458ee49de9d4193ae/maintainability" /></a>
